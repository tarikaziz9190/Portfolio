"use client";
import { useEffect, useState } from "react";
import { content, site } from "@/lib/content";
import { PKG_QUERY_EVENT } from "./Packages";

type F = { name: string; phone: string; email: string; service: string; message: string; budget: string };
const empty: F = { name: "", phone: "", email: "", service: "", message: "", budget: "" };
type Status = { kind: "idle" | "sending" | "ok" | "err"; text?: string };

export default function Contact() {
  const [f, setF] = useState<F>(empty);
  const [errs, setErrs] = useState<Partial<Record<keyof F, string>>>({});
  const [st, setSt] = useState<Status>({ kind: "idle" });
  const set = (k: keyof F) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF((p) => ({ ...p, [k]: e.target.value }));

  useEffect(() => {
    const h = (e: Event) => {
      const d = (e as CustomEvent<{ service: string; message: string }>).detail;
      setF((p) => ({ ...p, service: d.service, message: d.message }));
    };
    window.addEventListener(PKG_QUERY_EVENT, h);
    return () => window.removeEventListener(PKG_QUERY_EVENT, h);
  }, []);

  const validate = () => {
    const e: typeof errs = {};
    if (f.name.trim().length < 2) e.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) e.email = "Please enter a valid email.";
    if (!f.service) e.service = "Please choose a service.";
    if (f.message.trim().length < 10) e.message = "Please add a few details (10+ characters).";
    setErrs(e);
    return Object.keys(e).length === 0;
  };

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setSt({ kind: "sending" });
    try {
      const res = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
      const body = await res.json().catch(() => ({}));
      // success is shown only when the server confirms the save
      if (res.ok && body.ok === true) { setSt({ kind: "ok", text: "Thank you — your message was sent." }); setF(empty); }
      else setSt({ kind: "err", text: body.error ?? "Your message could not be sent. Please email or call instead." });
    } catch {
      setSt({ kind: "err", text: "Network error. Please try again, or email or call directly." });
    }
  };

  const Field = ({ k, label, children }: { k: keyof F; label: string; children: React.ReactNode }) => (
    <div className="form-field"><label htmlFor={`c-${k}`}>{label}</label>{children}{errs[k] && <div className="ferr" role="alert">{errs[k]}</div>}</div>
  );

  return (
    <section className="sec" id="contact">
      <div className="sec-lbl">Contact Now</div>
      <div className="contact-grid">
        <form className="contact-form" onSubmit={submit} noValidate>
          <div className="form-row">
            <Field k="name" label="Name"><input id="c-name" value={f.name} onChange={set("name")} placeholder="Your full name" autoComplete="name" /></Field>
            <Field k="phone" label="Contact No"><input id="c-phone" type="tel" value={f.phone} onChange={set("phone")} placeholder="+880 1XXX XXXXXX" autoComplete="tel" /></Field>
          </div>
          <Field k="email" label="Email"><input id="c-email" type="email" value={f.email} onChange={set("email")} placeholder="your@email.com" autoComplete="email" /></Field>
          <Field k="service" label="Service Interested In">
            <select id="c-service" value={f.service} onChange={set("service")}>
              <option value="" disabled>Select a service / package</option>
              {content.services.map((s) => <option key={s.id} value={s.name}>{s.name}</option>)}
              <option value="Other">Other / General Enquiry</option>
            </select>
          </Field>
          <Field k="message" label="Project Details & Requirements"><textarea id="c-message" value={f.message} onChange={set("message")} placeholder={f.service ? `Tell me about your ${f.service} requirements…` : "Tell me about your project or requirement…"} /></Field>
          <Field k="budget" label="Budget (optional)">
            <select id="c-budget" value={f.budget} onChange={set("budget")}>
              <option value="">Select your budget range</option>
              {site.budgets.map((b) => <option key={b}>{b}</option>)}
            </select>
          </Field>
          <button className="form-submit" type="submit" disabled={st.kind === "sending"}>{st.kind === "sending" ? "Sending…" : "Send Message"}</button>
          {st.text && <p className={`form-msg ${st.kind === "ok" ? "ok" : "err"}`} role="status">{st.text}</p>}
        </form>

        <div className="contact-info">
          <div className="ci-block">
            <div className="ci-label">Contact Info</div>
            <a className="ci-item" href={`mailto:${site.email}`}><i className="ti ti-mail" aria-hidden="true" /> {site.email}</a>
            <a className="ci-item" href={site.phoneHref}><i className="ti ti-phone" aria-hidden="true" /> {site.phone}</a>
            <div className="ci-item"><i className="ti ti-map-pin" aria-hidden="true" /> {site.address}</div>
          </div>
          <div className="ci-divider" />
          <div className="ci-block">
            <div className="ci-label">Portfolio Links</div>
            <div className="social-links">
              {site.socials.map((s) => <a key={s.title} className="social-link" href={s.href} target="_blank" rel="noopener noreferrer" title={s.title} aria-label={s.title}><i className={`ti ti-${s.icon}`} aria-hidden="true" /></a>)}
            </div>
          </div>
          <div className="ci-divider" />
          <div className="ci-block">
            <div className="ci-label">Availability</div>
            <div className="ci-item" style={{ pointerEvents: "none" }}><i className="ti ti-clock" aria-hidden="true" /> Available for new projects</div>
            <div className="ci-item" style={{ pointerEvents: "none" }}><i className="ti ti-world" aria-hidden="true" /> Remote & On-site · Dhaka</div>
          </div>
        </div>
      </div>
    </section>
  );
}
