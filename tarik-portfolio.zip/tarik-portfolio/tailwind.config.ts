import type { Config } from "tailwindcss";
// preflight off: the original stylesheet already carries its own reset
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  corePlugins: { preflight: false },
  theme: { extend: { colors: { gold: "#C9A96E", dark: "#0D0D0D" } } },
} satisfies Config;
