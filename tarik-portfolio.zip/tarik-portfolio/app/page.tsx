import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import { Stats, About, Services, Expertise, Tools, Skills, Career, Education, Footer } from "@/components/Sections";
import Work from "@/components/Work";
import Packages from "@/components/Packages";
import Contact from "@/components/Contact";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero /><Stats /><About /><Services /><Work /><Expertise /><Tools /><Skills />
        <Packages /><Career /><Education /><Contact />
      </main>
      <Footer />
    </>
  );
}
