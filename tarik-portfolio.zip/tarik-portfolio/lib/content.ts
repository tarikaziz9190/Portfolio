// Seed content migrated from portfolio_new.html. Phase 2 moves this into Supabase.
export const content = {
 "tags": [
  "Brand Identity",
  "UI/UX Design",
  "Social Media",
  "Facebook & Google Ads",
  "SEO",
  "Data Management",
  "Product Photo",
  "Video Editing"
 ],
 "about": [
  "I'm Tarik Aziz — an entrepreneur, visual designer, and digital marketer based in Dhaka, Bangladesh. With a background spanning education, IT, fashion, and creative direction, I bring a uniquely cross-disciplinary perspective to every project I take on.",
  "My work sits at the intersection of design and business strategy. Whether crafting a brand identity from scratch, running performance-driven Facebook & Google ad campaigns, or co-founding a fashion label, I approach everything with a results-first mindset and a deep love for visual storytelling.",
  "Currently serving as Co-Founder & Creative Director at Millennial Clothing, where I lead brand, marketing, and product development for a growing fashion & lifestyle brand."
 ],
 "facts": [
  {
   "key": "Full Name",
   "value": "Tarik Aziz"
  },
  {
   "key": "Date of Birth",
   "value": "21 December 1994"
  },
  {
   "key": "Nationality",
   "value": "Bangladeshi"
  },
  {
   "key": "Religion",
   "value": "Islam (Sunni)"
  },
  {
   "key": "Location",
   "value": "Mirpur-11, Dhaka"
  },
  {
   "key": "Languages",
   "value": "Bangla, English"
  },
  {
   "key": "Interests",
   "value": "Film · Music · Design · Travel"
  },
  {
   "key": "Blood Group",
   "value": "B+"
  }
 ],
 "services": [
  {
   "id": "digital-marketing",
   "icon": "speakerphone",
   "name": "Digital Marketing",
   "desc": "Full-funnel strategy — Meta Ads, Pixel setup, video content, product photography, and Google Ads to grow your presence."
  },
  {
   "id": "uiux",
   "icon": "layout-dashboard",
   "name": "UI/UX Design",
   "desc": "Frontend & backend UI/UX design, full page builds, responsive and non-responsive — pixel-perfect at every breakpoint."
  },
  {
   "id": "brand-identity",
   "icon": "vector-bezier-2",
   "name": "Brand Identity",
   "desc": "Logo, stationeries, official documents, web icons, fonts, color systems, banners — cohesive identities built to last."
  },
  {
   "id": "products-development",
   "icon": "box",
   "name": "Products Development",
   "desc": "Color variation, all-over print, print design, packaging and other product development solutions end to end."
  },
  {
   "id": "products-photo",
   "icon": "camera",
   "name": "Products Photo",
   "desc": "Photoshoot & editing for web heroes, banners, social posters, thumbnails, and infographics — clean visuals that convert."
  },
  {
   "id": "video-editing",
   "icon": "video",
   "name": "Video Editing",
   "desc": "Edit-only or full shoot & edit — polished video content for ads, social media, and brand storytelling."
  },
  {
   "id": "seo",
   "icon": "search",
   "name": "SEO",
   "desc": "On-page SEO, product content writing, and keyword research — organic visibility built for sustainable growth."
  },
  {
   "id": "products-content",
   "icon": "file-text",
   "name": "Products Content",
   "desc": "Product photo, video, descriptions, tags, keywords, and target audience — complete content for any platform."
  }
 ],
 "pkgCards": [
  {
   "id": "digital-marketing",
   "icon": null,
   "name": "Digital Marketing",
   "desc": "Full-funnel strategy covering Meta Ads, Pixel, video content, product photography, and Google Ads."
  },
  {
   "id": "uiux",
   "icon": null,
   "name": "UI/UX Design",
   "desc": "Frontend & backend UI, full page builds, responsive or fixed — from wireframes to pixel-perfect delivery."
  },
  {
   "id": "brand-identity",
   "icon": null,
   "name": "Brand Identity",
   "desc": "Logo, stationeries, official docs, web icons, fonts, colors, banners — complete brand system."
  },
  {
   "id": "products-development",
   "icon": null,
   "name": "Products Development",
   "desc": "Color variation, all-over print, print design, packaging and other product development work."
  },
  {
   "id": "products-photo",
   "icon": null,
   "name": "Products Photo",
   "desc": "Photoshoot & editing for web, social, and e-commerce — hero images, banners, thumbnails, infographics."
  },
  {
   "id": "video-editing",
   "icon": null,
   "name": "Video Editing",
   "desc": "Edit only, or full shoot & edit — short-form and long-form video for ads, social, and brand storytelling."
  },
  {
   "id": "seo",
   "icon": null,
   "name": "SEO",
   "desc": "On-page SEO, product content writing, keyword research — organic growth that compounds over time."
  },
  {
   "id": "products-content",
   "icon": null,
   "name": "Products Content",
   "desc": "Product photo, video, description, tags, keywords, target audience — full content for any platform."
  }
 ],
 "pkgData": {
  "digital-marketing": {
   "label": "Package — Digital Marketing",
   "title": "Digital Marketing",
   "subtitle": "Select all services you need",
   "color": "#C8A96E",
   "groups": [
    {
     "label": "Choose Your Services",
     "multi": true,
     "options": [
      "Meta Ads",
      "Pixel Setting",
      "Video Content",
      "Product Photo",
      "Google Ads"
     ]
    }
   ]
  },
  "uiux": {
   "label": "Package — UI/UX Design",
   "title": "UI/UX Design",
   "subtitle": "Configure your design requirements",
   "color": "#9B89C4",
   "groups": [
    {
     "label": "Design Type",
     "multi": true,
     "options": [
      "Frontend UI/UX",
      "Backend UI/UX",
      "Pages"
     ]
    },
    {
     "label": "Responsive",
     "multi": false,
     "options": [
      "Responsive",
      "Not Responsive"
     ]
    }
   ]
  },
  "brand-identity": {
   "label": "Package — Brand Identity",
   "title": "Brand Identity",
   "subtitle": "Select what you need for your brand",
   "color": "#C8A96E",
   "groups": [
    {
     "label": "Choose Deliverables",
     "multi": true,
     "options": [
      "Logo",
      "Stationeries (Card / Envelope / Letter Head)",
      "Official Documents",
      "Web Icon",
      "Font",
      "Color Palette",
      "Banner",
      "Other"
     ]
    }
   ]
  },
  "products-development": {
   "label": "Package — Products Development",
   "title": "Products Development",
   "subtitle": "Select your product design requirements",
   "color": "#A0B88A",
   "groups": [
    {
     "label": "Product Type",
     "multi": true,
     "options": [
      "Color Variation",
      "All Over Print Design",
      "Print Design",
      "Packaging",
      "Other"
     ]
    }
   ]
  },
  "products-photo": {
   "label": "Package — Products Photo",
   "title": "Products Photo",
   "subtitle": "Select shoot type and output format",
   "color": "#7BA7BC",
   "groups": [
    {
     "label": "Service Type",
     "multi": false,
     "options": [
      "Photoshoot + Edit",
      "Edit Only"
     ]
    },
    {
     "label": "Output Format",
     "multi": true,
     "options": [
      "Web Hero",
      "Web Banner",
      "Social Media Poster",
      "Web Thumbnail",
      "Infographic"
     ]
    }
   ]
  },
  "video-editing": {
   "label": "Package — Video Editing",
   "title": "Video Editing",
   "subtitle": "Choose your video service",
   "color": "#E07B5A",
   "groups": [
    {
     "label": "Service Type",
     "multi": false,
     "options": [
      "Edit Only",
      "Shoot & Edit"
     ]
    }
   ]
  },
  "seo": {
   "label": "Package — SEO",
   "title": "SEO",
   "subtitle": "Select your SEO requirements",
   "color": "#6AAECC",
   "groups": [
    {
     "label": "Services Needed",
     "multi": true,
     "options": [
      "On Page SEO",
      "Product Content Writing",
      "Keyword Research"
     ]
    }
   ]
  },
  "products-content": {
   "label": "Package — Products Content",
   "title": "Products Content",
   "subtitle": "Select what content you need",
   "color": "#D4875A",
   "groups": [
    {
     "label": "Content Type",
     "multi": true,
     "options": [
      "Product Photo",
      "Product Video",
      "Product Description",
      "Tags & Keywords",
      "Target Audience"
     ]
    }
   ]
  }
 },
 "categories": [
  {
   "id": "brand",
   "label": "Brand Identity",
   "icon": "◈",
   "color": "#C8A96E",
   "items": [
    {
     "title": "Millennial Clothing",
     "type": "Clothing Brand",
     "desc": "Full brand identity system — logo, color palette, typography, and brand guidelines for a modern clothing label.",
     "tags": [
      "Logo",
      "Brand Guide",
      "Typography"
     ]
    },
    {
     "title": "Gallerie Vespa",
     "type": "E-Commerce Website",
     "desc": "Complete brand identity for an e-commerce fashion platform, including visual language, UI tone, and digital assets.",
     "tags": [
      "E-Commerce",
      "Web Identity",
      "Digital"
     ]
    },
    {
     "title": "Dorbaa Sports",
     "type": "E-Commerce Website",
     "desc": "Sports-focused brand identity crafted for an e-commerce store, with bold visual elements and energetic color systems.",
     "tags": [
      "Sports",
      "E-Commerce",
      "Bold Design"
     ]
    },
    {
     "title": "Zathro",
     "type": "Amazon FBA",
     "desc": "Brand identity built for Amazon FBA marketplace presence — product branding, packaging concepts, and listing visuals.",
     "tags": [
      "Amazon",
      "FBA",
      "Packaging"
     ]
    },
    {
     "title": "Legend",
     "type": "Facebook Page",
     "desc": "Social-first brand identity designed for a Facebook page, optimized for engagement, reach, and brand recall.",
     "tags": [
      "Social Media",
      "Facebook",
      "Content"
     ]
    },
    {
     "title": "Dhumketu",
     "type": "Clothing Brand",
     "desc": "A cultural and fashion-forward clothing brand identity with expressive design elements rooted in local aesthetics.",
     "tags": [
      "Fashion",
      "Culture",
      "Apparel"
     ]
    }
   ]
  },
  {
   "id": "video",
   "label": "Video Editing",
   "icon": "▶",
   "color": "#E07B5A",
   "items": [
    {
     "title": "Prom Video",
     "type": "Event Film",
     "desc": "Cinematic prom event video with color grading, music sync, and storytelling edits that capture the emotion of the night.",
     "tags": [
      "Cinematic",
      "Color Grade",
      "Event"
     ]
    },
    {
     "title": "Products Show Off",
     "type": "Product Video",
     "desc": "High-energy product showcase reels designed to highlight features and drive purchase intent across digital channels.",
     "tags": [
      "Product",
      "Showcase",
      "Commercial"
     ]
    },
    {
     "title": "Awareness Video",
     "type": "Campaign",
     "desc": "Purposeful awareness campaign video with narrative-driven storytelling and motion graphics for broader reach.",
     "tags": [
      "Campaign",
      "Motion",
      "Storytelling"
     ]
    },
    {
     "title": "FB Reels",
     "type": "Facebook Content",
     "desc": "Short-form Facebook Reels crafted for maximum retention, optimized for the platform's algorithm and mobile viewing.",
     "tags": [
      "Facebook",
      "Short-form",
      "Reels"
     ]
    },
    {
     "title": "TikTok Reels",
     "type": "TikTok Content",
     "desc": "Trend-aware TikTok videos edited for viral potential — fast cuts, captions, and hooks designed for the FYP.",
     "tags": [
      "TikTok",
      "Viral",
      "Trending"
     ]
    },
    {
     "title": "YouTube Shorts & Reels",
     "type": "YouTube Content",
     "desc": "Vertical format YouTube Shorts edited for discovery, with strong hooks, pacing, and call-to-action moments.",
     "tags": [
      "YouTube",
      "Shorts",
      "Vertical"
     ]
    }
   ]
  },
  {
   "id": "photo",
   "label": "Product Photo",
   "icon": "⬡",
   "color": "#7BA7BC",
   "items": [
    {
     "title": "Website Thumbnail",
     "type": "Digital Asset",
     "desc": "Crisp, scroll-stopping thumbnails optimized for web use — designed for clarity at small sizes and high visual impact.",
     "tags": [
      "Thumbnail",
      "Web",
      "Digital"
     ]
    },
    {
     "title": "Website Hero Photo",
     "type": "Hero Visual",
     "desc": "Large-format hero imagery with intentional composition, lighting, and retouching for website banner use.",
     "tags": [
      "Hero",
      "Banner",
      "Website"
     ]
    },
    {
     "title": "Cover Photos",
     "type": "Social & Web",
     "desc": "Social media and website cover photos with layout-aware composition to work across different display contexts.",
     "tags": [
      "Cover",
      "Social",
      "Layout"
     ]
    },
    {
     "title": "Fashion Product",
     "type": "Fashion Photography",
     "desc": "Styled fashion product photography with clean or lifestyle backgrounds, color-corrected and retouched to brand standard.",
     "tags": [
      "Fashion",
      "Apparel",
      "Retouch"
     ]
    },
    {
     "title": "Gadgets",
     "type": "Tech Photography",
     "desc": "Sleek, minimal gadget photography that emphasizes form, detail, and premium feel for e-commerce and ads.",
     "tags": [
      "Tech",
      "Gadget",
      "Minimal"
     ]
    },
    {
     "title": "Gym & Sports",
     "type": "Active Photography",
     "desc": "Dynamic sports and gym product photography with energy, movement, and performance-focused visual language.",
     "tags": [
      "Sports",
      "Gym",
      "Active"
     ]
    },
    {
     "title": "Utensils",
     "type": "Kitchenware Photography",
     "desc": "Clean, well-lit utensil product photography for kitchenware brands — styled for both e-commerce and editorial use.",
     "tags": [
      "Kitchen",
      "Utensils",
      "Editorial"
     ]
    },
    {
     "title": "Others",
     "type": "Miscellaneous",
     "desc": "A diverse range of product photography spanning categories that don't fit a single label — each treated with the same precision.",
     "tags": [
      "Diverse",
      "Product",
      "Photography"
     ]
    }
   ]
  },
  {
   "id": "uiux",
   "label": "UI/UX Design",
   "icon": "◻",
   "color": "#9B89C4",
   "items": [
    {
     "title": "Millennial Clothing",
     "type": "Full Stack UI Collaboration",
     "desc": "Main UI theme and complete design guide for building a full-stack website, co-developed with @Nikoliarie as the design foundation.",
     "tags": [
      "Full Stack",
      "Collaboration",
      "System Design"
     ]
    },
    {
     "title": "Lumea",
     "type": "Fashion Website Frontend",
     "desc": "Frontend UI for a fashion-forward e-commerce website — elegant layouts, refined typography, and smooth user flows.",
     "tags": [
      "Fashion",
      "Frontend",
      "E-Commerce"
     ]
    },
    {
     "title": "LM10",
     "type": "Biographical Website",
     "desc": "A biographical website dedicated to Lionel Messi — immersive storytelling through timeline, stats, and rich visual design.",
     "tags": [
      "Sports",
      "Biography",
      "Visual Story"
     ]
    },
    {
     "title": "UniPOS Pro",
     "type": "POS Software UI",
     "desc": "Complete UI design for a point-of-sale software system built for fashion retailers — intuitive, fast, and feature-complete.",
     "tags": [
      "POS",
      "Software",
      "Enterprise UI"
     ]
    }
   ]
  },
  {
   "id": "social",
   "label": "Social Media",
   "icon": "◉",
   "color": "#5BAD8F",
   "items": [
    {
     "title": "Business Awareness Poster",
     "type": "Marketing Design",
     "desc": "Professionally designed posters that communicate a brand's value proposition clearly for social media distribution.",
     "tags": [
      "Poster",
      "Brand",
      "Marketing"
     ]
    },
    {
     "title": "Products Poster",
     "type": "Product Marketing",
     "desc": "Visually compelling product posters crafted to highlight key features and drive engagement across social platforms.",
     "tags": [
      "Product",
      "Poster",
      "Engagement"
     ]
    },
    {
     "title": "Social Awareness Poster",
     "type": "Cause Design",
     "desc": "Impactful social cause posters with message-first design — crafted to educate, inspire, and drive action.",
     "tags": [
      "Awareness",
      "Social Cause",
      "Impact"
     ]
    },
    {
     "title": "Product Infographic",
     "type": "Infographic Design",
     "desc": "Data-driven and visually clear product infographics that break down features, comparisons, or usage in digestible formats.",
     "tags": [
      "Infographic",
      "Data",
      "Product"
     ]
    }
   ]
  },
  {
   "id": "data",
   "label": "Data Management",
   "icon": "⬢",
   "color": "#D4875A",
   "items": [
    {
     "title": "UniPOS Pro",
     "type": "Full Structure + Accounting",
     "desc": "Complete database and accounting structure for UniPOS Pro — inventory, sales, returns, and financial reporting systems.",
     "tags": [
      "Database",
      "Accounting",
      "POS"
     ]
    },
    {
     "title": "Company Assessment",
     "type": "Millennial Clothing",
     "desc": "Comprehensive business data assessment for Millennial Clothing — operational analysis, data structuring, and reporting.",
     "tags": [
      "Assessment",
      "Business",
      "Analytics"
     ]
    }
   ]
  },
  {
   "id": "seo",
   "label": "SEO",
   "icon": "◎",
   "color": "#6AAECC",
   "items": [
    {
     "title": "Millennial Clothing Website SEO",
     "type": "Website SEO",
     "desc": "End-to-end SEO strategy and implementation for the Millennial Clothing website — on-page, technical, and keyword work.",
     "tags": [
      "SEO",
      "Website",
      "On-page"
     ]
    },
    {
     "title": "Millennial Clothing — All Products Content",
     "type": "Content SEO",
     "desc": "Product content writing and SEO optimization across the full Millennial Clothing product catalog.",
     "tags": [
      "Content",
      "Product SEO",
      "Copywriting"
     ]
    },
    {
     "title": "Daraz Store — All Products Content",
     "type": "Marketplace SEO",
     "desc": "Optimized product listings and SEO content for the Millennial Clothing Daraz store for marketplace visibility.",
     "tags": [
      "Daraz",
      "Marketplace",
      "Listings"
     ]
    }
   ]
  },
  {
   "id": "business",
   "label": "Business Management",
   "icon": "◐",
   "color": "#C4A882",
   "items": [
    {
     "title": "HR Management Research",
     "type": "Small Company Research",
     "desc": "In-depth research on HR management systems and best practices tailored for small businesses and growing teams.",
     "tags": [
      "HR",
      "Research",
      "Operations"
     ]
    }
   ]
  },
  {
   "id": "ads",
   "label": "Ads",
   "icon": "◑",
   "color": "#E08080",
   "items": [
    {
     "title": "Meta Ads Guideline",
     "type": "Ads Strategy",
     "desc": "A structured Meta Ads guideline document covering campaign setup, audience targeting, budget pacing, and creative specs.",
     "tags": [
      "Meta",
      "Facebook Ads",
      "Strategy"
     ]
    },
    {
     "title": "Meta Ads Key Rules",
     "type": "Ads Compliance",
     "desc": "Core rules and compliance guidelines for running effective Meta Ads — policy-aware and performance-focused.",
     "tags": [
      "Rules",
      "Compliance",
      "Meta"
     ]
    },
    {
     "title": "Meta Ads Content Idea",
     "type": "Creative Strategy",
     "desc": "Creative content idea frameworks for Meta Ads — hooks, formats, and messaging angles for different business goals.",
     "tags": [
      "Creative",
      "Content",
      "Ideas"
     ]
    }
   ]
  },
  {
   "id": "product",
   "label": "Product Development & Design",
   "icon": "◈",
   "color": "#A0B88A",
   "items": [
    {
     "title": "Product Mockup",
     "type": "Mockup Design",
     "desc": "Realistic and presentation-ready product mockups for apparel, packaging, and digital products across various use cases.",
     "tags": [
      "Mockup",
      "Presentation",
      "Design"
     ]
    },
    {
     "title": "Factory Ready Design Layout",
     "type": "Production Layout",
     "desc": "Technical design layouts prepared for factory production — print-ready files with bleed, specs, and measurement guides.",
     "tags": [
      "Production",
      "Print Ready",
      "Technical"
     ]
    }
   ]
  },
  {
   "id": "others",
   "label": "Other Activities",
   "icon": "✦",
   "color": "#B89AC4",
   "items": [
    {
     "title": "Digital Sketch",
     "type": "Illustration",
     "desc": "Freehand digital sketches exploring form, character, and concept — raw creative output from the illustration process.",
     "tags": [
      "Sketch",
      "Freehand",
      "Digital"
     ]
    },
    {
     "title": "Silhouette",
     "type": "Vector Art",
     "desc": "Bold silhouette artworks in vector format — fashion figures, characters, and abstract forms with strong graphic presence.",
     "tags": [
      "Silhouette",
      "Vector",
      "Graphic"
     ]
    },
    {
     "title": "Digital Art",
     "type": "Creative Art",
     "desc": "Finished digital artworks spanning a range of styles — from painterly to graphic, each piece a complete creative expression.",
     "tags": [
      "Digital Art",
      "Creative",
      "Illustration"
     ]
    },
    {
     "title": "Random Clicks",
     "type": "Photography",
     "desc": "A candid photography collection — unplanned, authentic moments captured through an observant and curious eye.",
     "tags": [
      "Photography",
      "Candid",
      "Moments"
     ]
    }
   ]
  }
 ],
 "expertise": [
  {
   "icon": "vector-bezier-2",
   "name": "Brand Identity",
   "sub": "Logo, Visual Systems, Brand Guidelines"
  },
  {
   "icon": "layout-dashboard",
   "name": "UI/UX Design",
   "sub": "Wireframes, Prototypes, User Flows"
  },
  {
   "icon": "brand-instagram",
   "name": "Social Media Design",
   "sub": "Posts, Stories, Reels, Templates"
  },
  {
   "icon": "database",
   "name": "Data Management",
   "sub": "Databases, Spreadsheets, Dashboards"
  },
  {
   "icon": "ad-2",
   "name": "Facebook & Google Ads",
   "sub": "Campaign Strategy, Targeting, ROAS"
  },
  {
   "icon": "search",
   "name": "SEO & Content",
   "sub": "On-Page, Technical SEO, Copywriting"
  },
  {
   "icon": "camera",
   "name": "Products Photo",
   "sub": "Photography, Retouching, Composition"
  },
  {
   "icon": "video",
   "name": "Video Editing",
   "sub": "Promo Reels, Ads, Social Content"
  }
 ],
 "tools": [
  {
   "icon": "brand-adobe",
   "name": "Illustrator"
  },
  {
   "icon": "brand-adobe",
   "name": "Photoshop"
  },
  {
   "icon": "brand-adobe",
   "name": "InDesign"
  },
  {
   "icon": "brand-adobe",
   "name": "After Effects"
  },
  {
   "icon": "brand-adobe",
   "name": "Premiere Pro"
  },
  {
   "icon": "video",
   "name": "Camtasia"
  },
  {
   "icon": "video",
   "name": "CapCut"
  },
  {
   "icon": "brand-figma",
   "name": "Figma"
  },
  {
   "icon": "layout-kanban",
   "name": "Canva"
  },
  {
   "icon": "brand-wordpress",
   "name": "WordPress"
  },
  {
   "icon": "table",
   "name": "MS Office"
  },
  {
   "icon": "brand-google",
   "name": "Google Sheets/Docs"
  }
 ],
 "ai": [
  {
   "icon": "robot",
   "name": "ChatGPT"
  },
  {
   "icon": "robot",
   "name": "Claude"
  },
  {
   "icon": "robot",
   "name": "Gemini"
  },
  {
   "icon": "notebook",
   "name": "NotebookLM"
  },
  {
   "icon": "microphone",
   "name": "ElevenLabs"
  },
  {
   "icon": "headphones",
   "name": "Shuno AI"
  },
  {
   "icon": "video",
   "name": "Veo"
  },
  {
   "icon": "wand",
   "name": "Runway"
  }
 ],
 "aiAreas": [
  "Image Generation",
  "Video Generation",
  "Content Writing",
  "Design",
  "UI/UX",
  "Database",
  "Research"
 ],
 "skills": {
  "design": [
   {
    "name": "Brand & Visual Design",
    "pct": 95
   },
   {
    "name": "Adobe Photoshop",
    "pct": 92
   },
   {
    "name": "Adobe Illustrator",
    "pct": 88
   },
   {
    "name": "Video Editing",
    "pct": 85
   },
   {
    "name": "Social Media Design",
    "pct": 93
   }
  ],
  "marketing": [
   {
    "name": "Facebook & Google Ads",
    "pct": 90
   },
   {
    "name": "SEO Strategy",
    "pct": 85
   },
   {
    "name": "Creative Direction",
    "pct": 92
   },
   {
    "name": "Data Management",
    "pct": 82
   },
   {
    "name": "Business Management",
    "pct": 86
   }
  ]
 },
 "career": [
  {
   "year": "2024 – Present",
   "company": "Millennial Clothing",
   "place": "millennial-clothing.com",
   "role": "Co-Founder & Creative Director",
   "industry": "Fashion & Lifestyle",
   "desc": "Leading creative direction, brand strategy, and marketing for a self-founded fashion & lifestyle label. Responsible for full brand identity, product development, and digital marketing execution."
  },
  {
   "year": "2022 – 2024",
   "company": "ISOLTECH IT",
   "place": "Nikunjo-2, Dhaka",
   "role": "IT Expert — Product Sourcing",
   "industry": "USA-Based Dropshipping",
   "desc": "Product sourcing, listing optimisation, and database management for a USA-based e-commerce dropshipping operation. Applied analytical and design skills to improve product visibility."
  },
  {
   "year": "2018 – 2019",
   "company": "The Brilliant College",
   "place": "Uttara, Dhaka",
   "role": "Lecturer",
   "industry": "Education",
   "desc": "Delivered lectures in Accounting and Finance. Developed strong communication and presentation skills through structured teaching."
  },
  {
   "year": "2014 – 2019",
   "company": "Study Center",
   "place": "Dhakshinkhan, Dhaka",
   "role": "Assistant Teacher",
   "industry": "Education",
   "desc": "Taught Accounting, Finance, Management, Marketing, and English to students at a private learning centre over five years."
  }
 ],
 "education": [
  {
   "degree": "MBA, Management Studies",
   "institution": "Jagannath University, Dhaka",
   "year": "2019 – 2020",
   "score": "CGPA 3.25 / 4.00"
  },
  {
   "degree": "BBA, Management Studies",
   "institution": "Jagannath University, Dhaka",
   "year": "2013 – 2014",
   "score": "CGPA 3.38 / 4.00"
  },
  {
   "degree": "HSC, Science",
   "institution": "Govt. Akbar Ali College, Rajshahi",
   "year": "2012",
   "score": "GPA 4.10 / 5.00"
  },
  {
   "degree": "SSC, Science",
   "institution": "Kaliakoir Adarsha High School",
   "year": "2010",
   "score": "GPA 5.00 / 5.00"
  }
 ]
} as const;

export type Category = (typeof content.categories)[number];
export type PkgId = keyof typeof content.pkgData;

export const site = {
  name: "Tarik Aziz",
  role: "Entrepreneur & Visual Storyteller",
  eyebrow: "Portfolio 2026",
  location: "Dhaka, Bangladesh · Available for work",
  email: "tarikaziz815@gmail.com",
  phone: "+88 017 4974 8939",
  phoneHref: "tel:+8801749748939",
  address: "Mirpur-11, Dhaka, Bangladesh",
  facebook: "https://www.facebook.com/tarik.aziz.1293",
  // Social URLs not provided in the source file (were "#"). Add real URLs to show them.
  socials: [
    { icon: "brand-facebook", title: "Facebook", href: "https://www.facebook.com/tarik.aziz.1293" },
  ] as { icon: string; title: string; href: string }[],
  stats: [
    { n: "10", sup: "+", l: "Years Experience" },
    { n: "MBA", sup: "", l: "Jagannath University" },
    { n: "8", sup: "", l: "Services Offered" },
    { n: "2", sup: "", l: "Languages" },
  ],
  nav: [["About","#about"],["Services","#services"],["Work","#work"],["Expertise","#expertise"],["Packages","#packages"],["Contact","#contact"]] as [string,string][],
  budgets: ["Under $100","$100 – $300","$300 – $500","$500 – $1,000","$1,000 – $3,000","$3,000+","Let's discuss"],
};
