import { NextResponse } from "next/server";

// Placeholder until Phase 2 (Supabase). Deliberately never reports success,
// so the form can't show a false "sent" message.
export async function POST() {
  return NextResponse.json(
    { ok: false, error: "The contact form isn't connected to the database yet. Please email or call for now." },
    { status: 503 },
  );
}
