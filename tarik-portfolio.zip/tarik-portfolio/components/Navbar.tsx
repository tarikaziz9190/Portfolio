"use client";
import { useState } from "react";
import { site } from "@/lib/content";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <nav className="navbar" aria-label="Main">
      <a className="nav-brand" href="#top">{site.name}</a>
      <div className={`nav-links${open ? " open" : ""}`} id="nav-links">
        {site.nav.map(([label, href]) => (
          <a key={href} href={href} onClick={() => setOpen(false)}>{label}</a>
        ))}
      </div>
      <button className="nav-toggle" aria-label="Toggle menu" aria-expanded={open} aria-controls="nav-links" onClick={() => setOpen(!open)}>
        <i className={`ti ti-${open ? "x" : "menu-2"}`} aria-hidden="true" />
      </button>
    </nav>
  );
}
