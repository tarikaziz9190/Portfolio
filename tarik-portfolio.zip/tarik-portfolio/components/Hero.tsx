import Image from "next/image";
import { content, site } from "@/lib/content";

export default function Hero() {
  return (
    <header className="hero" id="top">
      <div className="hero-left">
        <div className="eyebrow">{site.eyebrow}</div>
        <h1 className="hero-name">Tarik<br /><em>Aziz</em></h1>
        <div className="hero-role">{site.role}</div>
        <div className="hero-sub">{site.location}</div>
        <div className="tags">{content.tags.map((t) => <span className="tag" key={t}>{t}</span>)}</div>
        <div className="contacts">
          <a className="clink" href={`mailto:${site.email}`}><i className="ti ti-mail" aria-hidden="true" /> {site.email}</a>
          <a className="clink" href={site.phoneHref}><i className="ti ti-phone" aria-hidden="true" /> {site.phone}</a>
          <a className="clink" href={site.facebook} target="_blank" rel="noopener noreferrer"><i className="ti ti-brand-facebook" aria-hidden="true" /> facebook.com/tarik.aziz.1293</a>
          <span className="clink"><i className="ti ti-map-pin" aria-hidden="true" /> {site.address}</span>
        </div>
      </div>
      <div className="hero-photo">
        <Image src="/images/profile.jpg" alt="Portrait of Tarik Aziz" fill priority sizes="(max-width: 820px) 100vw, 320px" style={{ objectFit: "cover", objectPosition: "center top" }} />
        <div className="photo-name">{site.name}</div>
      </div>
    </header>
  );
}
