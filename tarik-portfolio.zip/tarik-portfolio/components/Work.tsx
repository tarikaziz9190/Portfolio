"use client";
import { useEffect, useState } from "react";
import { content, type Category } from "@/lib/content";

type Item = Category["items"][number];

export default function Work() {
  const [cat, setCat] = useState<Category | null>(null);
  const [item, setItem] = useState<Item | null>(null);

  useEffect(() => {
    if (!item) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setItem(null);
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = ""; window.removeEventListener("keydown", onKey); };
  }, [item]);

  const count = (n: number) => `${n} ${n === 1 ? "project" : "projects"}`;

  return (
    <section className="sec" id="work">
      <div className="sec-lbl">Selected Work</div>
      {!cat ? (
        <div>
          <p className="pf-intro-desc">A curated collection spanning brand identity, visual design, digital content, and business strategy.</p>
          <div className="pf-cat-grid">
            {content.categories.map((c) => {
              const preview = c.items.slice(0, 3).map((i) => i.title).join(", ") + (c.items.length > 3 ? ` +${c.items.length - 3} more` : "");
              return (
                <button key={c.id} className="pf-cat-card" style={{ textAlign: "left", font: "inherit", color: "inherit" }} onClick={() => setCat(c)}>
                  <span className="pf-cat-icon" style={{ color: c.color }} aria-hidden="true">{c.icon}</span>
                  <div className="pf-cat-title">{c.label}</div>
                  <div className="pf-cat-count">{count(c.items.length)}</div>
                  <div className="pf-cat-preview">{preview}</div>
                  <div className="pf-cat-link" style={{ marginTop: 20, color: c.color }}>View Work →</div>
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="pf-items-view" style={{ display: "block" }}>
          <button className="pf-back-btn" onClick={() => setCat(null)}>← All Categories</button>
          <div className="pf-items-header">
            <span style={{ fontSize: "2rem", color: cat.color }} aria-hidden="true">{cat.icon}</span>
            <h2 className="pf-items-title">{cat.label}</h2>
          </div>
          <p className="pf-items-num">— {count(cat.items.length)}</p>
          <div className="pf-items-grid">
            {cat.items.map((it) => (
              <button key={it.title} className="pf-item-card" style={{ textAlign: "left", font: "inherit", color: "inherit", ["--pf-accent" as string]: cat.color }} onClick={() => setItem(it)}>
                <div className="pf-item-title">{it.title}</div>
                <div className="pf-item-type">{it.type}</div>
                <div className="pf-item-desc">{it.desc}</div>
                <div className="pf-item-tags">{it.tags.map((t) => <span className="pf-tag" key={t} style={{ borderLeft: `2px solid ${cat.color}33` }}>{t}</span>)}</div>
                <div className="pf-item-cta" style={{ marginTop: 20, color: cat.color }}>View Details →</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {cat && item && (
        <div className="pf-modal-overlay" style={{ display: "flex" }} onClick={() => setItem(null)} role="dialog" aria-modal="true" aria-label={item.title}>
          <div className="pf-modal-box" onClick={(e) => e.stopPropagation()}>
            <button className="pf-modal-close" onClick={() => setItem(null)} aria-label="Close">×</button>
            <p className="pf-modal-label" style={{ color: cat.color }}>{cat.label}</p>
            <h2 className="pf-modal-title">{item.title}</h2>
            <p className="pf-modal-type">{item.type}</p>
            <div className="pf-modal-divider" />
            <p className="pf-modal-desc">{item.desc}</p>
            <div className="pf-item-tags" style={{ marginBottom: 32 }}>
              {item.tags.map((t) => <span className="pf-tag" key={t} style={{ borderLeft: `2px solid ${cat.color}55`, color: `${cat.color}CC` }}>{t}</span>)}
            </div>
            <button className="pf-modal-cta" onClick={() => setItem(null)} style={{ color: "#888", borderColor: "#2A2A2A" }}>Close</button>
          </div>
        </div>
      )}
    </section>
  );
}
