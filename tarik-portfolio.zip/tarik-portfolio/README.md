# Tarik Aziz — Portfolio (frontend, phase 1)

Next.js (App Router) + TypeScript + Tailwind. Content is seeded from `portfolio_new.html` into `lib/content.ts`.
Original stylesheet kept in `app/globals.css` (Tailwind preflight is off so the design is unchanged).

    npm install
    npm run dev      # http://localhost:3000
    npm run build

Not connected yet: `/api/contact` returns 503 on purpose (no fake success). Supabase, admin and RLS come in the next phase.
