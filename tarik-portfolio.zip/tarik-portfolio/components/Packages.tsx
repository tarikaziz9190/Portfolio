"use client";
import { useEffect, useState } from "react";
import { content, type PkgId } from "@/lib/content";

export const PKG_QUERY_EVENT = "pkg-query";

export default function Packages() {
  const [open, setOpen] = useState<PkgId | null>(null);
  const [sel, setSel] = useState<Record<number, string[]>>({});
  const data = open ? content.pkgData[open] : null;
  const icon = (id: string) => content.services.find((s) => s.id === id)?.icon ?? "box";

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = ""; window.removeEventListener("keydown", onKey); };
  }, [open]);

  const close = () => { setOpen(null); setSel({}); };
  const toggle = (gi: number, opt: string, multi: boolean) =>
    setSel((s) => {
      const cur = s[gi] ?? [];
      const next = cur.includes(opt) ? cur.filter((o) => o !== opt) : multi ? [...cur, opt] : [opt];
      return { ...s, [gi]: next };
    });

  const sendQuery = () => {
    if (!data) return;
    const parts = [`${data.title} Package`];
    data.groups.forEach((g, gi) => (sel[gi]?.length ? parts.push(`${g.label}: ${sel[gi].join(", ")}`) : null));
    window.dispatchEvent(new CustomEvent(PKG_QUERY_EVENT, { detail: { service: data.title, message: parts.join(" | ") } }));
    close();
    setTimeout(() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" }), 150);
  };

  return (
    <section className="sec" id="packages">
      <div className="sec-lbl">Packages</div>
      <div className="pkg-grid">
        {content.pkgCards.map((p) => (
          <button className="pkg-card" id={`pkg-${p.id}`} key={p.id} onClick={() => setOpen(p.id as PkgId)}>
            <div className="pkg-icon"><i className={`ti ti-${icon(p.id)}`} aria-hidden="true" /></div>
            <div className="pkg-name">{p.name}</div>
            <div className="pkg-desc">{p.desc}</div>
            <div className="pkg-card-hint">Select Options →</div>
          </button>
        ))}
      </div>

      {data && (
        <div className="pkg-modal-overlay" onClick={close} role="dialog" aria-modal="true" aria-label={data.title}>
          <div className="pkg-modal-box" onClick={(e) => e.stopPropagation()}>
            <button className="pkg-modal-close" onClick={close} aria-label="Close">×</button>
            <p className="pkg-modal-service-label" style={{ color: data.color }}>{data.label}</p>
            <h2 className="pkg-modal-title">{data.title}</h2>
            <p className="pkg-modal-subtitle">{data.subtitle}</p>
            <div className="pkg-modal-divider" />
            {data.groups.map((g, gi) => (
              <div key={g.label} style={{ marginBottom: 24 }}>
                <p className="pkg-opt-label">{g.label} {g.multi ? "(multiple allowed)" : "(choose one)"}</p>
                <div className="pkg-options-wrap">
                  {g.options.map((o) => {
                    const on = sel[gi]?.includes(o);
                    return (
                      <button key={o} aria-pressed={!!on} className={`pkg-opt-chip${on ? " selected" : ""}`}
                        style={on ? { background: data.color, color: "#0E0E0E", borderColor: data.color } : undefined}
                        onClick={() => toggle(gi, o, g.multi)}>{o}</button>
                    );
                  })}
                </div>
              </div>
            ))}
            <button className="pkg-query-btn" onClick={sendQuery}>Send Query to Contact Form</button>
          </div>
        </div>
      )}
    </section>
  );
}
