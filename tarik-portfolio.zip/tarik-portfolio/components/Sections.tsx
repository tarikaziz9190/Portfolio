import { content, site } from "@/lib/content";

const Sec = ({ id, label, children }: { id?: string; label: string; children: React.ReactNode }) => (
  <section className="sec" id={id}><div className="sec-lbl">{label}</div>{children}</section>
);
const Icon = ({ n }: { n: string }) => <i className={`ti ti-${n}`} aria-hidden="true" />;

export function Stats() {
  return (
    <div className="stats">
      {site.stats.map((s) => (
        <div className="stat" key={s.l}>
          <div className="stat-n">{s.n}{s.sup && <span className="stat-sup">{s.sup}</span>}</div>
          <div className="stat-l">{s.l}</div>
        </div>
      ))}
    </div>
  );
}

export function About() {
  const [p1, p2, p3] = content.about;
  const [pre, post] = p3.split("Millennial Clothing");
  return (
    <Sec id="about" label="About">
      <div className="about-grid">
        <div className="about-text">
          <p>{p1}</p><p>{p2}</p>
          <p>{pre}<strong style={{ color: "var(--gold-l)", fontWeight: 400 }}>Millennial Clothing</strong>{post}</p>
        </div>
        <div className="about-facts">
          {content.facts.map((f) => (
            <div className="fact-row" key={f.key}><span className="fact-key">{f.key}</span><span className="fact-val">{f.value}</span></div>
          ))}
        </div>
      </div>
    </Sec>
  );
}

export function Services() {
  return (
    <Sec id="services" label="Services">
      <div className="svc-grid">
        {content.services.map((s, i) => (
          <a className="svc" key={s.id} href={`#pkg-${s.id}`} title={`View ${s.name} package`}>
            <div className="svc-num">{String(i + 1).padStart(2, "0")}</div>
            <div className="svc-icon"><Icon n={s.icon} /></div>
            <div className="svc-name">{s.name}</div>
            <div className="svc-desc">{s.desc}</div>
            <div className="svc-redirect-hint">View Package →</div>
          </a>
        ))}
      </div>
    </Sec>
  );
}

export function Expertise() {
  return (
    <Sec id="expertise" label="Expertise">
      <div className="exp-grid">
        {content.expertise.map((e) => (
          <div className="exp-card" key={e.name}>
            <div className="exp-icon"><Icon n={e.icon} /></div>
            <div className="exp-name">{e.name}</div><div className="exp-sub">{e.sub}</div>
          </div>
        ))}
      </div>
    </Sec>
  );
}

export function Tools() {
  const pill = (t: { icon: string; name: string }) => <span className="tool-pill" key={t.name}><Icon n={t.icon} /> {t.name}</span>;
  return (
    <Sec label="Tools & AI Expertise">
      <div className="tools-section-grid">
        <div><div className="tools-group-label">Tools Expertise</div><div className="tools-row">{content.tools.map(pill)}</div></div>
        <div>
          <div className="tools-group-label">AI Apps Expertise</div>
          <div className="tools-row" style={{ marginBottom: 20 }}>{content.ai.map(pill)}</div>
          <div className="tools-group-label" style={{ fontSize: 14, marginBottom: 12 }}>AI Expertise Areas</div>
          <div className="ai-pills">{content.aiAreas.map((a) => <span className="ai-pill" key={a}>{a}</span>)}</div>
        </div>
      </div>
    </Sec>
  );
}

export function Skills() {
  const group = (title: string, items: readonly { name: string; pct: number }[]) => (
    <div>
      <div className="sk-group-title">{title}</div>
      <div className="sk-bars">
        {items.map((s) => (
          <div key={s.name}>
            <div className="sk-hdr"><span>{s.name}</span><span className="sk-pct">{s.pct}%</span></div>
            <div className="bar-track" role="img" aria-label={`${s.name} ${s.pct}%`}><div className="bar-fill" style={{ width: `${s.pct}%` }}><div className="bar-dot" /></div></div>
          </div>
        ))}
      </div>
    </div>
  );
  return <Sec label="Skills"><div className="skills-wrap">{group("Design & Creative", content.skills.design)}{group("Marketing & Business", content.skills.marketing)}</div></Sec>;
}

export function Career() {
  return (
    <Sec label="Career">
      <div className="timeline">
        {content.career.map((c) => (
          <div className="tl-item" key={c.year}>
            <div className="tl-left"><div className="tl-year">{c.year}</div><div className="tl-co">{c.company}<br />{c.place}</div><div className="tl-dot" /></div>
            <div className="tl-right"><div className="tl-role">{c.role}</div><div className="tl-industry">{c.industry}</div><div className="tl-desc">{c.desc}</div></div>
          </div>
        ))}
      </div>
    </Sec>
  );
}

export function Education() {
  return (
    <Sec label="Education">
      <div className="edu-grid">
        {content.education.map((e) => (
          <div className="edu-card" key={e.degree}>
            <div className="edu-deg">{e.degree}</div><div className="edu-inst">{e.institution}</div>
            <div className="edu-year">{e.year}</div><div className="edu-gpa">{e.score}</div>
          </div>
        ))}
      </div>
    </Sec>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div className="footer-brand">{site.name}<span>{site.role}</span></div>
        <nav className="footer-nav" aria-label="Footer">{site.nav.map(([l, h]) => <a key={h} href={h}>{l}</a>)}</nav>
        <div className="footer-social">
          {site.socials.map((s) => <a key={s.title} href={s.href} target="_blank" rel="noopener noreferrer" title={s.title} aria-label={s.title}><Icon n={s.icon} /></a>)}
        </div>
      </div>
      <div className="footer-divider" />
      <div className="footer-bottom">
        <div className="foot-copy">© 2026 {site.name} · {site.address} · {site.phone} · {site.email}</div>
        <div className="foot-sig">Crafted with intent.</div>
      </div>
    </footer>
  );
}
